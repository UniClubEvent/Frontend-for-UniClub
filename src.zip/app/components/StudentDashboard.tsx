import { Calendar, Clock, MapPin, Users, Filter, Search, CheckCircle } from "lucide-react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { useState } from "react";
import { useNavigate } from "react-router";

interface Event {
  id: number;
  title: string;
  club: string;
  date: string;
  time: string;
  location: string;
  attendees: number;
  maxAttendees: number;
  status: "approved" | "pending";
  registered: boolean;
  category: string;
}

const mockEvents: Event[] = [
  {
    id: 1,
    title: "Tech Talk: AI in Modern Development",
    club: "Computer Science Club",
    date: "2026-03-05",
    time: "18:00",
    location: "Engineering Building - Room 301",
    attendees: 45,
    maxAttendees: 60,
    status: "approved",
    registered: false,
    category: "Workshop"
  },
  {
    id: 2,
    title: "Spring Networking Mixer",
    club: "Business Society",
    date: "2026-03-08",
    time: "19:00",
    location: "Student Center - Hall A",
    attendees: 78,
    maxAttendees: 100,
    status: "approved",
    registered: true,
    category: "Social"
  },
  {
    id: 3,
    title: "Community Service Day",
    club: "Volunteer Club",
    date: "2026-03-12",
    time: "09:00",
    location: "City Park",
    attendees: 32,
    maxAttendees: 50,
    status: "approved",
    registered: false,
    category: "Service"
  },
  {
    id: 4,
    title: "Photography Exhibition Opening",
    club: "Photography Club",
    date: "2026-03-15",
    time: "17:00",
    location: "Arts Building - Gallery",
    attendees: 25,
    maxAttendees: 40,
    status: "approved",
    registered: false,
    category: "Exhibition"
  },
];

export function StudentDashboard() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [registeredEvents, setRegisteredEvents] = useState<Set<number>>(
    new Set(mockEvents.filter(e => e.registered).map(e => e.id))
  );

  const handleRegister = (eventId: number) => {
    setRegisteredEvents(prev => {
      const newSet = new Set(prev);
      if (newSet.has(eventId)) {
        newSet.delete(eventId);
      } else {
        newSet.add(eventId);
      }
      return newSet;
    });
  };

  const filteredEvents = mockEvents.filter(event =>
    event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    event.club.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const upcomingCount = filteredEvents.length;
  const registeredCount = registeredEvents.size;

  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {/* Welcome Section */}
        <div className="mb-6">
          <h2 className="text-2xl sm:text-3xl text-[#1E3A8A] mb-2">Welcome, Student</h2>
          <p className="text-[#6B7280]">Discover and join upcoming club events</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card className="p-4 sm:p-6 bg-white rounded-lg shadow-sm border border-[#E5E7EB]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[#6B7280] mb-1">Upcoming Events</p>
                <p className="text-2xl sm:text-3xl font-semibold text-[#1F2937]">{upcomingCount}</p>
              </div>
              <div className="bg-[#DBEAFE] p-3 rounded-lg">
                <Calendar className="w-6 h-6 text-[#1E3A8A]" />
              </div>
            </div>
          </Card>

          <Card className="p-4 sm:p-6 bg-white rounded-lg shadow-sm border border-[#E5E7EB]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[#6B7280] mb-1">My Registrations</p>
                <p className="text-2xl sm:text-3xl font-semibold text-[#1F2937]">{registeredCount}</p>
              </div>
              <div className="bg-[#D1FAE5] p-3 rounded-lg">
                <CheckCircle className="w-6 h-6 text-[#10B981]" />
              </div>
            </div>
          </Card>

          <Card className="p-4 sm:p-6 bg-white rounded-lg shadow-sm border border-[#E5E7EB]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[#6B7280] mb-1">Active Clubs</p>
                <p className="text-2xl sm:text-3xl font-semibold text-[#1F2937]">12</p>
              </div>
              <div className="bg-[#CCFBF1] p-3 rounded-lg">
                <Users className="w-6 h-6 text-[#0D9488]" />
              </div>
            </div>
          </Card>

          <Card className="p-4 sm:p-6 bg-white rounded-lg shadow-sm border border-[#E5E7EB]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[#6B7280] mb-1">This Week</p>
                <p className="text-2xl sm:text-3xl font-semibold text-[#1F2937]">3</p>
              </div>
              <div className="bg-[#FEF3C7] p-3 rounded-lg">
                <Clock className="w-6 h-6 text-[#F59E0B]" />
              </div>
            </div>
          </Card>
        </div>

        {/* Search and Filter */}
        <div className="bg-white rounded-lg shadow-sm border border-[#E5E7EB] p-4 mb-6">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[#6B7280] w-5 h-5" />
              <Input
                placeholder="Search events or clubs..."
                className="pl-10 bg-[#F9FAFB] border-[#E5E7EB]"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button variant="outline" className="border-[#E5E7EB] text-[#1F2937]">
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
          </div>
        </div>

        {/* Events List */}
        <div className="space-y-4">
          <h3 className="text-xl text-[#1F2937] mb-4">Upcoming Events</h3>
          
          {filteredEvents.map((event) => (
            <Card key={event.id} className="bg-white rounded-lg shadow-sm border border-[#E5E7EB] overflow-hidden hover:shadow-md transition-shadow">
              <div className="p-4 sm:p-6">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <h4 className="text-lg font-semibold text-[#1F2937] mb-1">{event.title}</h4>
                        <p className="text-sm text-[#0D9488] mb-2">{event.club}</p>
                      </div>
                      <Badge className="bg-[#DBEAFE] text-[#1E3A8A] border-0 ml-2">
                        {event.category}
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-sm text-[#6B7280]">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-[#1E3A8A]" />
                        <span>{new Date(event.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-[#1E3A8A]" />
                        <span>{event.time}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-[#1E3A8A]" />
                        <span>{event.location}</span>
                      </div>
                    </div>
                    
                    <div className="mt-3">
                      <div className="flex items-center gap-2 text-sm text-[#6B7280]">
                        <Users className="w-4 h-4" />
                        <span>{event.attendees}/{event.maxAttendees} attendees</span>
                      </div>
                      <div className="mt-2 bg-[#E5E7EB] rounded-full h-2 overflow-hidden">
                        <div
                          className="bg-[#0D9488] h-full"
                          style={{ width: `${(event.attendees / event.maxAttendees) * 100}%` }}
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex lg:flex-col gap-2">
                    {registeredEvents.has(event.id) ? (
                      <Button
                        onClick={() => handleRegister(event.id)}
                        className="bg-[#10B981] hover:bg-[#059669] text-white w-full lg:w-32"
                      >
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Registered
                      </Button>
                    ) : (
                      <Button
                        onClick={() => handleRegister(event.id)}
                        className="bg-[#1E3A8A] hover:bg-[#1E40AF] text-white w-full lg:w-32"
                      >
                        Register
                      </Button>
                    )}
                    <Button
                      variant="outline"
                      className="border-[#E5E7EB] text-[#1F2937] w-full lg:w-32"
                      onClick={() => navigate(`/events/${event.id}`)}
                    >
                      Details
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}