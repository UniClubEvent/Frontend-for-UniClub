import { Calendar, Users, AlertCircle, TrendingUp, CheckCircle, Clock, XCircle, Search, Filter, BarChart3, CalendarDays } from "lucide-react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { useState } from "react";
import { useNavigate } from "react-router";

interface EventRequest {
  id: number;
  title: string;
  club: string;
  date: string;
  time: string;
  location: string;
  expectedAttendees: number;
  status: "pending" | "approved" | "rejected";
  submittedDate: string;
  category: string;
}

const mockEventRequests: EventRequest[] = [
  {
    id: 1,
    title: "Coding Bootcamp for Beginners",
    club: "Computer Science Club",
    date: "2026-03-20",
    time: "14:00",
    location: "Computer Lab 2",
    expectedAttendees: 30,
    status: "pending",
    submittedDate: "2026-02-25",
    category: "Workshop"
  },
  {
    id: 2,
    title: "Annual Charity Gala",
    club: "Volunteer Club",
    date: "2026-04-10",
    time: "19:00",
    location: "Grand Hall",
    expectedAttendees: 150,
    status: "pending",
    submittedDate: "2026-02-26",
    category: "Fundraiser"
  },
  {
    id: 3,
    title: "Spring Networking Mixer",
    club: "Business Society",
    date: "2026-03-08",
    time: "19:00",
    location: "Student Center - Hall A",
    expectedAttendees: 100,
    status: "approved",
    submittedDate: "2026-02-20",
    category: "Social"
  },
  {
    id: 4,
    title: "Late Night Concert",
    club: "Music Club",
    date: "2026-03-15",
    time: "22:00",
    location: "Auditorium",
    expectedAttendees: 200,
    status: "rejected",
    submittedDate: "2026-02-22",
    category: "Entertainment"
  },
];

interface Club {
  id: number;
  name: string;
  category: string;
  members: number;
  activeEvents: number;
  status: "active" | "inactive";
  president: string;
}

const mockClubs: Club[] = [
  { id: 1, name: "Computer Science Club", category: "Technology", members: 125, activeEvents: 3, status: "active", president: "Alex Johnson" },
  { id: 2, name: "Business Society", category: "Business", members: 98, activeEvents: 2, status: "active", president: "Maria Garcia" },
  { id: 3, name: "Volunteer Club", category: "Community Service", members: 76, activeEvents: 1, status: "active", president: "James Smith" },
  { id: 4, name: "Photography Club", category: "Arts", members: 45, activeEvents: 1, status: "active", president: "Emma Wilson" },
  { id: 5, name: "Music Club", category: "Arts", members: 62, activeEvents: 0, status: "active", president: "David Lee" },
];

interface ConflictEvent {
  id: number;
  event1: string;
  event2: string;
  location: string;
  date: string;
  time: string;
}

const mockConflicts: ConflictEvent[] = [
  {
    id: 1,
    event1: "Coding Bootcamp (CS Club)",
    event2: "Study Session (Math Club)",
    location: "Computer Lab 2",
    date: "2026-03-20",
    time: "14:00"
  },
];

export function SystemAdminDashboard() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("requests");
  const [searchQuery, setSearchQuery] = useState("");

  const pendingRequests = mockEventRequests.filter(e => e.status === "pending");
  const approvedRequests = mockEventRequests.filter(e => e.status === "approved");
  const rejectedRequests = mockEventRequests.filter(e => e.status === "rejected");

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "approved":
        return <Badge className="bg-[#D1FAE5] text-[#10B981] border-0">Approved</Badge>;
      case "pending":
        return <Badge className="bg-[#FEF3C7] text-[#F59E0B] border-0">Pending</Badge>;
      case "rejected":
        return <Badge className="bg-[#FEE2E2] text-[#EF4444] border-0">Rejected</Badge>;
      default:
        return null;
    }
  };

  const getClubStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-[#D1FAE5] text-[#10B981] border-0">Active</Badge>;
      case "inactive":
        return <Badge className="bg-[#E5E7EB] text-[#6B7280] border-0">Inactive</Badge>;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {/* Welcome Section */}
        <div className="mb-6">
          <h2 className="text-2xl sm:text-3xl text-[#1E3A8A] mb-2">System Administration</h2>
          <p className="text-[#6B7280]">Manage all university clubs and events</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card className="p-4 sm:p-6 bg-white rounded-lg shadow-sm border border-[#E5E7EB]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[#6B7280] mb-1">Total Clubs</p>
                <p className="text-2xl sm:text-3xl font-semibold text-[#1F2937]">{mockClubs.length}</p>
              </div>
              <div className="bg-[#DBEAFE] p-3 rounded-lg">
                <Users className="w-6 h-6 text-[#1E3A8A]" />
              </div>
            </div>
          </Card>

          <Card className="p-4 sm:p-6 bg-white rounded-lg shadow-sm border border-[#E5E7EB]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[#6B7280] mb-1">Pending Requests</p>
                <p className="text-2xl sm:text-3xl font-semibold text-[#1F2937]">{pendingRequests.length}</p>
              </div>
              <div className="bg-[#FEF3C7] p-3 rounded-lg">
                <Clock className="w-4 h-4 sm:w-6 sm:h-6 text-[#F59E0B]" />
              </div>
            </div>
          </Card>

          <Card className="p-4 sm:p-6 bg-white rounded-lg shadow-sm border border-[#E5E7EB]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[#6B7280] mb-1">Approved Events</p>
                <p className="text-2xl sm:text-3xl font-semibold text-[#1F2937]">{approvedRequests.length}</p>
              </div>
              <div className="bg-[#D1FAE5] p-3 rounded-lg">
                <CheckCircle className="w-6 h-6 text-[#10B981]" />
              </div>
            </div>
          </Card>

          <Card className="p-4 sm:p-6 bg-white rounded-lg shadow-sm border border-[#E5E7EB]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[#6B7280] mb-1">Conflicts</p>
                <p className="text-2xl sm:text-3xl font-semibold text-[#1F2937]">{mockConflicts.length}</p>
              </div>
              <div className="bg-[#FEE2E2] p-3 rounded-lg">
                <AlertCircle className="w-6 h-6 text-[#EF4444]" />
              </div>
            </div>
          </Card>
        </div>

        {/* Search Bar */}
        <div className="bg-white rounded-lg shadow-sm border border-[#E5E7EB] p-4 mb-6">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[#6B7280] w-5 h-5" />
              <Input
                placeholder="Search events, clubs, or locations..."
                className="pl-10 bg-[#F9FAFB] border-[#E5E7EB]"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button variant="outline" className="border-[#E5E7EB] text-[#1F2937]">
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
          </div>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-white border border-[#E5E7EB] mb-6">
            <TabsTrigger value="requests" className="data-[state=active]:bg-[#1E3A8A] data-[state=active]:text-white">
              Event Requests
            </TabsTrigger>
            <TabsTrigger value="clubs" className="data-[state=active]:bg-[#1E3A8A] data-[state=active]:text-white">
              Clubs
            </TabsTrigger>
            <TabsTrigger value="conflicts" className="data-[state=active]:bg-[#1E3A8A] data-[state=active]:text-white">
              Conflicts
            </TabsTrigger>
          </TabsList>

          <TabsContent value="requests" className="space-y-4">
            <h3 className="text-xl text-[#1F2937] mb-4">Event Approval Requests</h3>
            
            {mockEventRequests.map((request) => (
              <Card key={request.id} className="bg-white rounded-lg shadow-sm border border-[#E5E7EB] overflow-hidden">
                <div className="p-4 sm:p-6">
                  <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex flex-wrap items-start justify-between mb-2 gap-2">
                        <div className="flex-1">
                          <h4 className="text-lg font-semibold text-[#1F2937] mb-1">{request.title}</h4>
                          <p className="text-sm text-[#0D9488] mb-2">{request.club}</p>
                        </div>
                        <div className="flex gap-2">
                          {getStatusBadge(request.status)}
                          <Badge className="bg-[#DBEAFE] text-[#1E3A8A] border-0">
                            {request.category}
                          </Badge>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm text-[#6B7280] mb-2">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-[#1E3A8A]" />
                          <span>{new Date(request.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })} at {request.time}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Users className="w-4 h-4 text-[#1E3A8A]" />
                          <span>{request.expectedAttendees} expected attendees</span>
                        </div>
                      </div>

                      <p className="text-sm text-[#6B7280]">
                        <span className="font-medium">Location:</span> {request.location}
                      </p>
                      <p className="text-xs text-[#9CA3AF] mt-1">
                        Submitted on {new Date(request.submittedDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                      </p>
                    </div>
                    
                    {request.status === "pending" && (
                      <div className="flex lg:flex-col gap-2">
                        <Button className="bg-[#10B981] hover:bg-[#059669] text-white flex-1 lg:flex-none lg:w-32">
                          <CheckCircle className="w-4 h-4 mr-2" />
                          Approve
                        </Button>
                        <Button variant="outline" className="border-[#EF4444] text-[#EF4444] hover:bg-[#FEE2E2] flex-1 lg:flex-none lg:w-32">
                          <XCircle className="w-4 h-4 mr-2" />
                          Reject
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="clubs" className="space-y-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl text-[#1F2937]">Registered Clubs</h3>
              <Button className="bg-[#1E3A8A] hover:bg-[#1E40AF] text-white">
                Register New Club
              </Button>
            </div>

            <Card className="bg-white rounded-lg shadow-sm border border-[#E5E7EB] overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-[#F9FAFB] border-b border-[#E5E7EB]">
                    <tr>
                      <th className="px-4 sm:px-6 py-3 text-left text-xs font-medium text-[#6B7280] uppercase tracking-wider">
                        Club Name
                      </th>
                      <th className="px-4 sm:px-6 py-3 text-left text-xs font-medium text-[#6B7280] uppercase tracking-wider hidden md:table-cell">
                        Category
                      </th>
                      <th className="px-4 sm:px-6 py-3 text-left text-xs font-medium text-[#6B7280] uppercase tracking-wider">
                        Members
                      </th>
                      <th className="px-4 sm:px-6 py-3 text-left text-xs font-medium text-[#6B7280] uppercase tracking-wider hidden lg:table-cell">
                        Active Events
                      </th>
                      <th className="px-4 sm:px-6 py-3 text-left text-xs font-medium text-[#6B7280] uppercase tracking-wider hidden sm:table-cell">
                        Status
                      </th>
                      <th className="px-4 sm:px-6 py-3 text-left text-xs font-medium text-[#6B7280] uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-[#E5E7EB]">
                    {mockClubs.map((club) => (
                      <tr key={club.id} className="hover:bg-[#F9FAFB]">
                        <td className="px-4 sm:px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-[#1F2937]">{club.name}</div>
                          <div className="text-xs text-[#6B7280]">{club.president}</div>
                        </td>
                        <td className="px-4 sm:px-6 py-4 whitespace-nowrap text-sm text-[#6B7280] hidden md:table-cell">
                          {club.category}
                        </td>
                        <td className="px-4 sm:px-6 py-4 whitespace-nowrap text-sm text-[#1F2937]">
                          {club.members}
                        </td>
                        <td className="px-4 sm:px-6 py-4 whitespace-nowrap text-sm text-[#1F2937] hidden lg:table-cell">
                          {club.activeEvents}
                        </td>
                        <td className="px-4 sm:px-6 py-4 whitespace-nowrap hidden sm:table-cell">
                          {getClubStatusBadge(club.status)}
                        </td>
                        <td className="px-4 sm:px-6 py-4 whitespace-nowrap text-sm">
                          <Button variant="ghost" size="sm" className="text-[#1E3A8A]">
                            View
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="conflicts" className="space-y-4">
            <h3 className="text-xl text-[#1F2937] mb-4">Scheduling Conflicts</h3>
            
            {mockConflicts.length > 0 ? (
              mockConflicts.map((conflict) => (
                <Card key={conflict.id} className="bg-white rounded-lg shadow-sm border-l-4 border-l-[#EF4444] border-[#E5E7EB] overflow-hidden">
                  <div className="p-4 sm:p-6">
                    <div className="flex items-start gap-3">
                      <div className="bg-[#FEE2E2] p-2 rounded-lg">
                        <AlertCircle className="w-5 h-5 text-[#EF4444]" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold text-[#1F2937] mb-2">Location Conflict</h4>
                        <div className="space-y-1 text-sm text-[#6B7280]">
                          <p><span className="font-medium text-[#1F2937]">Event 1:</span> {conflict.event1}</p>
                          <p><span className="font-medium text-[#1F2937]">Event 2:</span> {conflict.event2}</p>
                          <p><span className="font-medium text-[#1F2937]">Location:</span> {conflict.location}</p>
                          <p><span className="font-medium text-[#1F2937]">Date:</span> {new Date(conflict.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })} at {conflict.time}</p>
                        </div>
                      </div>
                      <Button className="bg-[#1E3A8A] hover:bg-[#1E40AF] text-white">
                        Resolve
                      </Button>
                    </div>
                  </div>
                </Card>
              ))
            ) : (
              <Card className="bg-white rounded-lg shadow-sm border border-[#E5E7EB] p-8">
                <div className="text-center">
                  <CheckCircle className="w-12 h-12 text-[#10B981] mx-auto mb-3" />
                  <h4 className="text-lg font-medium text-[#1F2937] mb-1">No Conflicts</h4>
                  <p className="text-sm text-[#6B7280]">All events are properly scheduled without conflicts</p>
                </div>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}