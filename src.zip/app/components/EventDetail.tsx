import { Calendar, Clock, MapPin, Users, ArrowLeft, CheckCircle, AlertCircle } from "lucide-react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { useNavigate } from "react-router";
import { useState } from "react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function EventDetail() {
  const navigate = useNavigate();
  const [isRegistered, setIsRegistered] = useState(false);

  // Mock event data
  const event = {
    id: 1,
    title: "Tech Talk: AI in Modern Development",
    club: "Computer Science Club",
    date: "2026-03-05",
    time: "18:00",
    endTime: "20:00",
    location: "Engineering Building - Room 301",
    attendees: 45,
    maxAttendees: 60,
    registrationDeadline: "2026-03-03",
    category: "Workshop",
    description: "Join us for an exciting tech talk on how AI is revolutionizing modern software development. Our guest speaker, Dr. Sarah Johnson from TechCorp, will share insights on the latest AI tools and frameworks that are shaping the future of development. This session will cover practical applications, real-world case studies, and hands-on demonstrations. Whether you're a beginner or an experienced developer, you'll gain valuable knowledge about integrating AI into your projects. Don't miss this opportunity to network with fellow tech enthusiasts and industry professionals!",
    bannerUrl: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&h=400&fit=crop"
  };

  const spotsLeft = event.maxAttendees - event.attendees;
  const spotsPercentage = (event.attendees / event.maxAttendees) * 100;

  const handleRegister = () => {
    setIsRegistered(!isRegistered);
  };

  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      {/* Banner Image */}
      <div className="relative h-64 sm:h-80 lg:h-96 bg-gradient-to-r from-[#1E3A8A] to-[#0D9488]">
        <ImageWithFallback
          src={event.bannerUrl}
          alt={event.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        
        {/* Back Button */}
        <Button
          onClick={() => navigate(-1)}
          variant="ghost"
          className="absolute top-4 left-4 bg-white/90 hover:bg-white text-[#1F2937]"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 -mt-16 relative z-10 pb-12">
        <Card className="bg-white rounded-lg shadow-lg border border-[#E5E7EB] overflow-hidden">
          <div className="p-6 sm:p-8">
            {/* Header */}
            <div className="mb-6">
              <div className="flex flex-wrap items-center gap-2 mb-3">
                <Badge className="bg-[#DBEAFE] text-[#1E3A8A] border-0">
                  {event.category}
                </Badge>
                <Badge className="bg-[#CCFBF1] text-[#0D9488] border-0">
                  {event.club}
                </Badge>
              </div>
              <h1 className="text-2xl sm:text-3xl lg:text-4xl font-semibold text-[#1F2937] mb-4">
                {event.title}
              </h1>
            </div>

            {/* Event Info Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6 pb-6 border-b border-[#E5E7EB]">
              <div className="flex items-start gap-3">
                <div className="bg-[#DBEAFE] p-2 rounded-lg">
                  <Calendar className="w-5 h-5 text-[#1E3A8A]" />
                </div>
                <div>
                  <p className="text-sm text-[#6B7280]">Date</p>
                  <p className="font-medium text-[#1F2937]">
                    {new Date(event.date).toLocaleDateString('en-US', { 
                      weekday: 'long',
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-[#DBEAFE] p-2 rounded-lg">
                  <Clock className="w-5 h-5 text-[#1E3A8A]" />
                </div>
                <div>
                  <p className="text-sm text-[#6B7280]">Time</p>
                  <p className="font-medium text-[#1F2937]">
                    {event.time} - {event.endTime}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-[#DBEAFE] p-2 rounded-lg">
                  <MapPin className="w-5 h-5 text-[#1E3A8A]" />
                </div>
                <div>
                  <p className="text-sm text-[#6B7280]">Venue</p>
                  <p className="font-medium text-[#1F2937]">{event.location}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-[#DBEAFE] p-2 rounded-lg">
                  <Users className="w-5 h-5 text-[#1E3A8A]" />
                </div>
                <div>
                  <p className="text-sm text-[#6B7280]">Attendees</p>
                  <p className="font-medium text-[#1F2937]">
                    {event.attendees} / {event.maxAttendees}
                  </p>
                </div>
              </div>
            </div>

            {/* Description */}
            <div className="mb-6">
              <h3 className="text-xl font-semibold text-[#1F2937] mb-3">About This Event</h3>
              <p className="text-[#6B7280] leading-relaxed">{event.description}</p>
            </div>

            {/* Registration Info */}
            <Card className="bg-[#F9FAFB] border border-[#E5E7EB] p-4 mb-6">
              <div className="flex items-start gap-3 mb-4">
                <AlertCircle className="w-5 h-5 text-[#F59E0B] mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-[#1F2937] mb-1">
                    Registration Deadline
                  </p>
                  <p className="text-sm text-[#6B7280]">
                    {new Date(event.registrationDeadline).toLocaleDateString('en-US', { 
                      month: 'long', 
                      day: 'numeric',
                      year: 'numeric'
                    })}
                  </p>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-[#6B7280]">Available Slots</span>
                  <span className="font-medium text-[#1F2937]">
                    {spotsLeft} spots left
                  </span>
                </div>
                <div className="bg-[#E5E7EB] rounded-full h-3 overflow-hidden">
                  <div
                    className={`h-full transition-all ${
                      spotsPercentage >= 80 ? 'bg-[#EF4444]' : 
                      spotsPercentage >= 50 ? 'bg-[#F59E0B]' : 
                      'bg-[#10B981]'
                    }`}
                    style={{ width: `${spotsPercentage}%` }}
                  />
                </div>
              </div>
            </Card>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              {isRegistered ? (
                <Button
                  onClick={handleRegister}
                  className="flex-1 bg-[#10B981] hover:bg-[#059669] text-white"
                >
                  <CheckCircle className="w-5 h-5 mr-2" />
                  Registered - Click to Cancel
                </Button>
              ) : (
                <Button
                  onClick={handleRegister}
                  className="flex-1 bg-[#1E3A8A] hover:bg-[#1E40AF] text-white"
                  disabled={spotsLeft === 0}
                >
                  {spotsLeft === 0 ? "Event Full" : "Register for Event"}
                </Button>
              )}
              <Button
                variant="outline"
                className="border-[#E5E7EB] text-[#1F2937]"
              >
                Share Event
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
