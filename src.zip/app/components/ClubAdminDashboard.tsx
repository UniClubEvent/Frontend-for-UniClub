import { Calendar, Users, TrendingUp, Plus, Edit, Trash2, Eye, CheckCircle, Clock, XCircle, LayoutDashboard, FileText, UserCog, Package } from "lucide-react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { useState } from "react";
import { useNavigate } from "react-router";

interface ClubEvent {
  id: number;
  title: string;
  date: string;
  time: string;
  location: string;
  attendees: number;
  maxAttendees: number;
  status: "approved" | "pending" | "rejected";
  category: string;
}

const mockClubEvents: ClubEvent[] = [
  {
    id: 1,
    title: "Tech Talk: AI in Modern Development",
    date: "2026-03-05",
    time: "18:00",
    location: "Engineering Building - Room 301",
    attendees: 45,
    maxAttendees: 60,
    status: "approved",
    category: "Workshop"
  },
  {
    id: 2,
    title: "Coding Bootcamp for Beginners",
    date: "2026-03-20",
    time: "14:00",
    location: "Computer Lab 2",
    attendees: 0,
    maxAttendees: 30,
    status: "pending",
    category: "Workshop"
  },
  {
    id: 3,
    title: "Hackathon 2026",
    date: "2026-04-15",
    time: "09:00",
    location: "Innovation Hub",
    attendees: 0,
    maxAttendees: 100,
    status: "pending",
    category: "Competition"
  },
];

interface Member {
  id: number;
  name: string;
  email: string;
  role: string;
  joinDate: string;
}

const mockMembers: Member[] = [
  { id: 1, name: "Alex Johnson", email: "alex.j@university.edu", role: "President", joinDate: "2025-09-01" },
  { id: 2, name: "Sarah Williams", email: "sarah.w@university.edu", role: "Vice President", joinDate: "2025-09-01" },
  { id: 3, name: "Michael Chen", email: "michael.c@university.edu", role: "Member", joinDate: "2025-10-15" },
  { id: 4, name: "Emily Davis", email: "emily.d@university.edu", role: "Member", joinDate: "2025-11-02" },
];

export function ClubAdminDashboard() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("events");

  const approvedEvents = mockClubEvents.filter(e => e.status === "approved");
  const pendingEvents = mockClubEvents.filter(e => e.status === "pending");
  const totalAttendees = approvedEvents.reduce((sum, e) => sum + e.attendees, 0);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "approved":
        return <Badge className="bg-[#D1FAE5] text-[#10B981] border-0">Approved</Badge>;
      case "pending":
        return <Badge className="bg-[#FEF3C7] text-[#F59E0B] border-0">Pending</Badge>;
      case "rejected":
        return <Badge className="bg-[#FEE2E2] text-[#EF4444] border-0">Rejected</Badge>;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {/* Welcome Section */}
        <div className="mb-6">
          <h2 className="text-2xl sm:text-3xl text-[#1E3A8A] mb-2">Computer Science Club</h2>
          <p className="text-[#6B7280]">Manage your club events and members</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card className="p-4 sm:p-6 bg-white rounded-lg shadow-sm border border-[#E5E7EB]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[#6B7280] mb-1">Total Events</p>
                <p className="text-2xl sm:text-3xl font-semibold text-[#1F2937]">{mockClubEvents.length}</p>
              </div>
              <div className="bg-[#DBEAFE] p-3 rounded-lg">
                <Calendar className="w-6 h-6 text-[#1E3A8A]" />
              </div>
            </div>
          </Card>

          <Card className="p-4 sm:p-6 bg-white rounded-lg shadow-sm border border-[#E5E7EB]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[#6B7280] mb-1">Club Members</p>
                <p className="text-2xl sm:text-3xl font-semibold text-[#1F2937]">{mockMembers.length}</p>
              </div>
              <div className="bg-[#CCFBF1] p-3 rounded-lg">
                <Users className="w-6 h-6 text-[#0D9488]" />
              </div>
            </div>
          </Card>

          <Card className="p-4 sm:p-6 bg-white rounded-lg shadow-sm border border-[#E5E7EB]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[#6B7280] mb-1">Total Attendees</p>
                <p className="text-2xl sm:text-3xl font-semibold text-[#1F2937]">{totalAttendees}</p>
              </div>
              <div className="bg-[#D1FAE5] p-3 rounded-lg">
                <TrendingUp className="w-6 h-6 text-[#10B981]" />
              </div>
            </div>
          </Card>

          <Card className="p-4 sm:p-6 bg-white rounded-lg shadow-sm border border-[#E5E7EB]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[#6B7280] mb-1">Pending Approval</p>
                <p className="text-2xl sm:text-3xl font-semibold text-[#1F2937]">{pendingEvents.length}</p>
              </div>
              <div className="bg-[#FEF3C7] p-3 rounded-lg">
                <Clock className="w-6 h-6 text-[#F59E0B]" />
              </div>
            </div>
          </Card>
        </div>

        {/* Action Button */}
        <div className="mb-6">
          <Button className="bg-[#1E3A8A] hover:bg-[#1E40AF] text-white">
            <Plus className="w-4 h-4 mr-2" />
            Create New Event
          </Button>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-white border border-[#E5E7EB] mb-6">
            <TabsTrigger value="events" className="data-[state=active]:bg-[#1E3A8A] data-[state=active]:text-white">
              Events
            </TabsTrigger>
            <TabsTrigger value="members" className="data-[state=active]:bg-[#1E3A8A] data-[state=active]:text-white">
              Members
            </TabsTrigger>
          </TabsList>

          <TabsContent value="events" className="space-y-4">
            <h3 className="text-xl text-[#1F2937] mb-4">Your Events</h3>
            
            {mockClubEvents.map((event) => (
              <Card key={event.id} className="bg-white rounded-lg shadow-sm border border-[#E5E7EB] overflow-hidden">
                <div className="p-4 sm:p-6">
                  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <h4 className="text-lg font-semibold text-[#1F2937] mb-2">{event.title}</h4>
                          <div className="flex flex-wrap items-center gap-2 mb-3">
                            {getStatusBadge(event.status)}
                            <Badge className="bg-[#DBEAFE] text-[#1E3A8A] border-0">
                              {event.category}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm text-[#6B7280] mb-3">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-[#1E3A8A]" />
                          <span>{new Date(event.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })} at {event.time}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Users className="w-4 h-4 text-[#1E3A8A]" />
                          <span>{event.attendees}/{event.maxAttendees} registered</span>
                        </div>
                      </div>

                      {event.status === "approved" && event.attendees > 0 && (
                        <div className="mt-2">
                          <div className="bg-[#E5E7EB] rounded-full h-2 overflow-hidden">
                            <div
                              className="bg-[#0D9488] h-full"
                              style={{ width: `${(event.attendees / event.maxAttendees) * 100}%` }}
                            />
                          </div>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex lg:flex-col gap-2">
                      <Button variant="outline" className="border-[#E5E7EB] text-[#1F2937] flex-1 lg:flex-none lg:w-32">
                        <Eye className="w-4 h-4 mr-2" />
                        View
                      </Button>
                      <Button variant="outline" className="border-[#E5E7EB] text-[#1F2937] flex-1 lg:flex-none lg:w-32">
                        <Edit className="w-4 h-4 mr-2" />
                        Edit
                      </Button>
                      <Button variant="outline" className="border-[#E5E7EB] text-[#EF4444] flex-1 lg:flex-none lg:w-32">
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="members" className="space-y-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl text-[#1F2937]">Club Members</h3>
              <Button className="bg-[#0D9488] hover:bg-[#0F766E] text-white">
                <Plus className="w-4 h-4 mr-2" />
                Add Member
              </Button>
            </div>

            <Card className="bg-white rounded-lg shadow-sm border border-[#E5E7EB] overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-[#F9FAFB] border-b border-[#E5E7EB]">
                    <tr>
                      <th className="px-4 sm:px-6 py-3 text-left text-xs font-medium text-[#6B7280] uppercase tracking-wider">
                        Name
                      </th>
                      <th className="px-4 sm:px-6 py-3 text-left text-xs font-medium text-[#6B7280] uppercase tracking-wider hidden sm:table-cell">
                        Email
                      </th>
                      <th className="px-4 sm:px-6 py-3 text-left text-xs font-medium text-[#6B7280] uppercase tracking-wider">
                        Role
                      </th>
                      <th className="px-4 sm:px-6 py-3 text-left text-xs font-medium text-[#6B7280] uppercase tracking-wider hidden lg:table-cell">
                        Join Date
                      </th>
                      <th className="px-4 sm:px-6 py-3 text-left text-xs font-medium text-[#6B7280] uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-[#E5E7EB]">
                    {mockMembers.map((member) => (
                      <tr key={member.id} className="hover:bg-[#F9FAFB]">
                        <td className="px-4 sm:px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-[#1F2937]">{member.name}</div>
                          <div className="text-xs text-[#6B7280] sm:hidden">{member.email}</div>
                        </td>
                        <td className="px-4 sm:px-6 py-4 whitespace-nowrap hidden sm:table-cell">
                          <div className="text-sm text-[#6B7280]">{member.email}</div>
                        </td>
                        <td className="px-4 sm:px-6 py-4 whitespace-nowrap">
                          <Badge className={member.role === "President" || member.role === "Vice President" 
                            ? "bg-[#DBEAFE] text-[#1E3A8A] border-0" 
                            : "bg-[#E5E7EB] text-[#6B7280] border-0"}>
                            {member.role}
                          </Badge>
                        </td>
                        <td className="px-4 sm:px-6 py-4 whitespace-nowrap text-sm text-[#6B7280] hidden lg:table-cell">
                          {new Date(member.joinDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                        </td>
                        <td className="px-4 sm:px-6 py-4 whitespace-nowrap text-sm">
                          <Button variant="ghost" size="sm" className="text-[#1E3A8A]">
                            <Edit className="w-4 h-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}